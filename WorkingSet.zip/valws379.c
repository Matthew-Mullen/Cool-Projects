// CONCERNS TO TALK TO MATTHEW ABOUT
/* 1. Memory efficiency vs Speed efficiency of Queue vs LRU cache approach of keeping track of sliding window.
2. Order to put in overlapping page references for example page 1 at memory address 0x0000 0000 and the size is 10 but page 2 is at 0x0000 0008
Would I put in page 1 or page 2 first in the sliding window? */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "valsws379.h"

// use linked list like structure to preserve memory then the extra memory used in an array isn't wasted and we don't get seg fault allocating to little
// use double pointer to treat as hash table
int init(ull pg_size, ull win_size);

void update_from_driver();
void working_set(ull address,ull size_of_ref);
void free_heap();
void insert(ull address);
void delete(ull address);
void put_in_key(ull address);
void calculate_unique();
void free_all();

ull in_linked_list(ull page);
ull remove_key();
ull hash_func(ull address);
ull traverse_ht_node(ull key);

const ull MAX_MEMORY_SIZE=1.8446744e19-1;
ull count=0;
ull PAGE_SIZE;
ull WINDOW_SIZE;
ull NUMBER_OF_PAGES;
ull NUMBER_OF_WINDOWS;
ull ACCESS_COUNT = 0;
ull SKIP_UNTIL=0;
ull left;
ull right;
ull uniques=0;

int* page_array;
int* prev_working_sets;

struct mem_node** hashtable; 
struct mem_node* count_pages;
struct mem_node* queue;

int main(int argc, char* argv[]){
    if(argc!=5 && argc!=3){
        printf("invalid arguments.\n");
        //return 1;
    }
    ull skip_size=0;
    ull win_size;
    ull pg_size;
    if(strcmp(argv[1],"-s")!=0){
        pg_size=strtoull(argv[1],NULL,10);
        win_size=strtoull(argv[2],NULL,10);
    }
    else{
        skip_size=strtoull(argv[2],NULL,10);
        pg_size=strtoull(argv[3],NULL,10);
        win_size=strtoull(argv[4],NULL,10);
    }
    
    if(init(pg_size,win_size)==1){
        return 1;
    }
    //printf("Memory allocated.\n");
    update_from_driver();
    free_all();
    return 0;
}

void update_from_driver(){
    char buffer[100];
    //printf("did we print anything\n");
    int i=0;
    while(fgets(buffer,100,stdin)){
        buffer[99]='\0';
        if(strlen(buffer) == 0){
            break;
        }
        //printf("%d\n",i++);
        //printf("%s\n",buffer);
        char* access_type = strtok(buffer," ");
        char* address = strtok(NULL,",");
        char* size = strtok(NULL,",");
        if(address == NULL || size==NULL || access_type==NULL){
            continue;
        }
        
        ull addr = strtoull(address,NULL,16);
        ull m_size = strtoull(size,NULL,10);
        //printf("This is the address %lld\n",addr);
        //printf("address %lld\n",addr);
        working_set(addr,m_size);
        //free_heap();
    }
} 
// page number is the number of times page size divides an address
int init(ull pg_size, ull win_size){
    PAGE_SIZE=pg_size; // set global vars
    WINDOW_SIZE=win_size;
    NUMBER_OF_PAGES=MAX_MEMORY_SIZE / PAGE_SIZE;
    NUMBER_OF_WINDOWS=MAX_MEMORY_SIZE/WINDOW_SIZE;
    // setup memory (hashtable,current page array for working set, history array for num accesses to each working set)
    hashtable=malloc(WINDOW_SIZE/2*sizeof(struct mem_node ));
    ull key=0;
    while(key<WINDOW_SIZE/2){
        hashtable[key]=NULL;
        key++;
    }
    queue=malloc(sizeof(struct mem_node));
    queue->key=1.8446744e19-1;
    count_pages = malloc(sizeof(struct mem_node));
    count_pages->next=NULL;
    count_pages->key=1;
    if(hashtable==NULL || count_pages==NULL || queue==NULL){
        printf("Memory not allocated successfully\n");
        return 1;
    }
    return 0;
    
}

void working_set(ull address,ull size_of_ref){
    if(SKIP_UNTIL>0){
        SKIP_UNTIL--;
        return;
    }
    if(ACCESS_COUNT<WINDOW_SIZE){
        //printf("%lld\n", address);
        ull start = address / PAGE_SIZE;
        if((start+size_of_ref)/PAGE_SIZE!=start){ // check if need to insert twice due to page overlap
            insert(address);
            insert((start+size_of_ref));
            ACCESS_COUNT++;
        }
        else{
            insert(address);
        }
        calculate_unique();
        ACCESS_COUNT++;
        return;
    }
    ull start = address / PAGE_SIZE;
    if((start+size_of_ref)/PAGE_SIZE!=start){
        insert(address);
        insert((start+size_of_ref));
        delete(remove_key());
        delete(remove_key());
        ACCESS_COUNT++;
    }
    else{
        insert(address);
        delete(remove_key());
    }
    calculate_unique();
    ACCESS_COUNT++; // total number of accesses to any working set
}

ull hash_func(ull address){
    return address % WINDOW_SIZE/2; 
}

void insert(ull address){
    ull key = hash_func(address);
    put_in_key(address);
    if(hashtable[key]!=NULL){
        int flag=0;
        ull page=address/PAGE_SIZE;
        struct mem_node* cur = hashtable[key];
        while(cur->next!=NULL){
            cur=cur->next;
        }
        struct mem_node * newnode = malloc(sizeof(struct mem_node));
        newnode->address=address;
        newnode->page=page;
        cur->next=newnode;
        newnode->next=NULL;
        
    }
    else{
        struct mem_node * newnode = malloc(sizeof(struct mem_node));
        newnode->address=address;
        newnode->page=address/PAGE_SIZE;
        newnode->next=NULL;
        hashtable[key]=newnode;
    }
}


void delete(ull key){
    //ull key = hash_func(address);
    if(hashtable[key]!=NULL){
        struct mem_node * cur= hashtable[key];
        while(cur){
            //printf("address at this hashtable %lld\n",cur->address);
            cur=cur->next;
        }
        hashtable[key]=hashtable[key]->next;
        //cur->next=NULL;
    }

    else{
       printf("Invalid delete! Didn't exist in the first place!\n");
    }


}
void put_in_key(ull address){
    ull key = hash_func(address);
    //printf("key %lld inserted into queue\n",key);
    struct mem_node* cur=queue;
    if(cur->key==1.8446744e19-1){
        cur->key=key;
        return;
    }
    int i=0;
    while(cur->next){
        cur=cur->next;
    }
    struct mem_node * endofqueue = malloc(sizeof(struct mem_node ));
    endofqueue->key=key;
    endofqueue->next=NULL;
    cur->next=endofqueue;
}

ull remove_key(){
    //printf("when do we get here\n");
    //printf("key %lld deleted from queue\n",queue->key);
    ull removed = queue->key;
    queue=queue->next;
    return removed;
    
   
}

void calculate_unique(){
    ull uniques=0;
    //printf("these are the keys\n");
    ull key=0;
    while(key<WINDOW_SIZE/2){
        //printf("%lld ",counter->key);
        uniques+=traverse_ht_node(key);
        key++;
    }
    //printf("\n");
    printf("%lld %lld\n",ACCESS_COUNT,uniques);
    struct mem_node* curr = count_pages;
    //printf("these are the pages ");
    while(curr){
       //printf(" %lld ",curr->page);
        curr=curr->next;
    }
    //printf("\n");
    struct mem_node* cur = count_pages;
    cur=cur->next;
    while(cur){
        struct mem_node * temp=cur;
        
        cur=cur->next;
        free(temp);
    }
    count_pages->next=NULL;
    count_pages->key=1;
    
    
}

ull traverse_ht_node(ull key){
    struct mem_node* cur = hashtable[key];
    ull uniques=0;
    while(cur){
        uniques+=in_linked_list(cur->page);
        cur=cur->next;
    }
    return uniques;
}

ull in_linked_list(ull page){
    
    struct mem_node* cur= count_pages;
    if(cur->key==1){
        cur->page=page;
        cur->next=NULL;
        cur->key=0;
        //printf("does this always hit\n");
        return 1;
    }
    while(cur->next){
        if(cur->page==page){
            return 0;
        }
        cur=cur->next;
    }
    if(cur->page==page){
        return 0;
    }
    struct mem_node * new_page_detected = malloc(sizeof(struct mem_node));
    new_page_detected->next=NULL;
    new_page_detected->page=page;
    new_page_detected->key=0;
    cur->next=new_page_detected;
    return 1;
}

void free_all(){
    struct mem_node * temp;
    while(queue){
        temp=queue->next;
        free(queue);
        queue=temp;
    }
    temp=NULL;
    while(count_pages){
        temp=count_pages->next;
        free(count_pages);
        count_pages=temp;
    }
    for(ull i=0;i<WINDOW_SIZE/2;i++){
        temp=hashtable[i];
        struct mem_node * temp2;
        while(temp){
            temp2=temp->next;
            free(temp);
            temp=temp2;
        }
    }
}