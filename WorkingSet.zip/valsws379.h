/* Made by Matthew Mullen. Did not collaborate with anyone. */
typedef unsigned long long ull;

struct mem_node{ // add one of these each time we get a new window
    ull address;
    ull page;
    ull key;
    struct mem_node * next;
};