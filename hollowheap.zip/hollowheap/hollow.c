#include<stdio.h>
#include<stdlib.h>
#include <time.h>
#define N 10000000

struct Item{
    int value;
    struct Hollow_Heap_Node* node;
};
struct Hollow_Heap_Node{
    int rank;
    int num_children;
    struct Item * item;
    struct Hollow_Heap_Node * ep;
    struct Hollow_Heap_Node * next;
    struct Hollow_Heap_Node * child;
    int key;
};
struct Hollow_Heap{
    struct Hollow_Heap_Node* root;

};
//struct Hollow_Heap* hollowheap;
//struct Hollow_Heap_Node* head;
struct Hollow_Heap_Node** A;
int MAX_RANK=0;

struct Hollow_Heap_Node* make_heap_node(struct Item* e, int k){
    struct Hollow_Heap_Node* new_node = malloc(sizeof(struct Hollow_Heap_Node));
    new_node->key=k;
    e->node = new_node;
    new_node->item=e;
    new_node->num_children=0;
    new_node->next=NULL;
    new_node->child=NULL;
    new_node->rank=0;
    return new_node;
}
void add_child(struct Hollow_Heap_Node* v, struct Hollow_Heap_Node* w){
    v->next=w->child;
    w->child=v;
}
struct Hollow_Heap_Node* link(struct Hollow_Heap_Node* v, struct Hollow_Heap_Node* w){
    if(v->key >= w->key){
        add_child(v,w);
        //printf("Successfully inserted the item %d\n",v->item->value);
        return w;
    }
    else{
        add_child(w,v);
        //printf("Successfully inserted the item %d\n",w->item->value);
        return v;
    }

}
struct Hollow_Heap_Node* meld(struct Hollow_Heap_Node* v, struct Hollow_Heap_Node* w){
    if(v==NULL){
        return w;
    }
    else if(w==NULL){
        //printf("the first insert should be here. %d\n",v->item->value);
        return v;
    }
   // printf("do we linkup?\n");
   // printf("trying to print new item %d\n",v->item->value);
    return link(v,w);
}
struct Hollow_Heap_Node* insert(struct Item* e, int v, struct Hollow_Heap_Node* w){
    return meld(make_heap_node(e,v),w);
}

struct Item* find_min(struct Hollow_Heap_Node* h){
    if(h==NULL){
        return NULL;
    }
    return h->item;
}
struct Hollow_Heap_Node* decrease_key(struct Item* e, int key, struct Hollow_Heap_Node* head){
    struct Hollow_Heap_Node* u = e->node;
    if(u==head){
        u->key=key;
        return head;
    }
    struct Hollow_Heap_Node * v = make_heap_node(e,key);

    u->item=NULL;

    if(u->rank>2){
        v->rank=u->rank-2;
    }
    v->child=u;
    u->ep=v;
    return link(v,head);
}
struct Hollow_Heap_Node* do_ranked_lists(struct Hollow_Heap_Node* u){
    while(A[u->rank]!=NULL){
        u=link(u,A[u->rank]);
        A[u->rank]=NULL;
        u->rank++;
    }
    A[u->rank]=u;
    if(u->rank>MAX_RANK){
        MAX_RANK=u->rank;
    }
}

struct Hollow_Heap_Node* delete_heap_node(struct Item* e, struct Hollow_Heap_Node* hea){
    e->node->item=NULL;
    e->node=NULL;
    if(hea->item!=NULL){ // non minimum deletion
        return hea;
    }
    struct Hollow_Heap_Node * v;
    MAX_RANK=0;
    while(hea!=NULL){
        struct Hollow_Heap_Node * w = hea->child;
        v = hea;
        hea=hea->next;
        while(w!=NULL){
            struct Hollow_Heap_Node * u = w;
            w=w->next;
            if(u->item==NULL){
                if(u->ep==NULL){
                    u->next=hea;
                    hea=u;
                }
                else{
                    if(u->ep==v){
                        w=NULL;
                    }
                    else{
                        u->next=NULL;
                        u->ep=NULL;
                    }
                    //u->ep=NULL;
                }
            }
            else{
                do_ranked_lists(u);
            }
        //free(v);
        }
        //free(v);
    }
    //printf("%d max rank\n",MAX_RANK);
   for(int i = 0;i<=MAX_RANK;i++){
     if(A[i]!= NULL){
         if(hea==NULL){
             //printf("this it?");
             hea=A[i];
         }
         else{
             hea=link(hea,A[i]);
             A[i]=NULL;
         }
         A[i]=NULL;
     }
   }
    //free(v);
    //printf(" val %d\n",hea->item->value);
    return hea;
}
struct Hollow_Heap_Node* delete_min(struct Hollow_Heap_Node* hea){
    return delete_heap_node(hea->item,hea);
}


#define MAX_SIZE 10000000

// returns the index of the parent node
int parent(int i) {
    return (i - 1) / 2;
}

// return the index of the left child 
int left_child(int i) {
    return 2*i + 1;
}

// return the index of the right child 
int right_child(int i) {
    return 2*i + 2;
}

void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

// insert the item at the appropriate position
void insert2(int a[], int data, int *n) {
    if (*n >= MAX_SIZE) {
        printf("%s\n", "The heap is full. Cannot insert");
        return;
    }
    // first insert the time at the last position of the array 
    // and move it up
    a[*n] = data;
    *n = *n + 1;


    // move up until the heap property satisfies
    int i = *n - 1;
    while (i != 0 && a[parent(i)] < a[i]) {
        swap(&a[parent(i)], &a[i]);
        i = parent(i);
    }
}

// moves the item at position i of array a
// into its appropriate position
void max_heapify(int a[], int i, int n){
    // find left child node
    int left = left_child(i);

    // find right child node
    int right = right_child(i);

    // find the largest among 3 nodes
    int largest = i;

    // check if the left node is larger than the current node
    if (left <= n && a[left] > a[largest]) {
        largest = left;
    }

    // check if the right node is larger than the current node
    if (right <= n && a[right] > a[largest]) {
        largest = right;
    }

    // swap the largest node with the current node 
    // and repeat this process until the current node is larger than 
    // the right and the left node
    if (largest != i) {
        int temp = a[i];
        a[i] = a[largest];
        a[largest] = temp;
        max_heapify(a, largest, n);
    }

}

// converts an array into a heap
void build_max_heap(int a[], int n) {
    int i;
    for (i = n/2; i >= 0; i--) {
        max_heapify(a, i, n);
    } 
}

// returns the  maximum item of the heap
int get_max(int a[]) {
    return a[0];
}

// deletes the max item and return
int extract_max(int a[], int *n) {
    int max_item = a[0];

    // replace the first item with the last item
    a[0] = a[*n - 1];
    *n = *n - 1;

    // maintain the heap property by heapifying the 
    // first item
    max_heapify(a, 0, *n);
    return max_item;
}

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int main(){
    // setup hollow heap
    struct Hollow_Heap * hollowheap = malloc(sizeof(struct Hollow_Heap));
    hollowheap->root=NULL;
    A=malloc(N*sizeof(struct Hollow_Heap_Node*));
    for(int i=0;i<N;i++){
        A[i]=NULL;
    }
    // setup test array
    //int testarray[1000000];
    int * testarray=malloc(10000000*sizeof(int));
    int size_arr[]={10,100,1000,10000,100000,10000000};
    
    struct Item** item_arr=malloc(10000000*sizeof(struct Item));
    if(item_arr==NULL){
        printf("thats not good chief we got a malloc error");
        return 1;
    }
    for(int i=0;i<10000000;i++){
        item_arr[i]=malloc(sizeof(struct Item));
    }
    srand(time(NULL));   // Initialization, should only be called once.
    for(int cases=0;cases<=5;++cases){
        int n=size_arr[cases];
        for(int i=0;i<n;++i){
            testarray[i]=rand();
        }
        
        // HOLLOW HEAP TEST
        clock_t begin = clock();
        for(int i=0;i<n;i++){
            item_arr[i]->value=testarray[i];
            hollowheap->root=insert(item_arr[i],i,hollowheap->root);
        }
        clock_t end = clock();
        double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        printf("To insert %d integers the hollow heap took %lf seconds\n",n,time_spent);
        for(int i=0;i<n;i++){
            hollowheap->root=delete_min(hollowheap->root);
        }
        for(int i=0;i<n;i++){
            item_arr[i]->value=testarray[i];
        }
        begin=clock();
        for(int i=0;i<n;i++){
            hollowheap->root=insert(item_arr[i],i,hollowheap->root);
        }
        end=clock();
        time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        printf("To insert %d integers after accounting for Item allocation time the hollow heap took %lf seconds\n",n,time_spent);
        begin=clock();
        for(int i=0;i<n;i++){
            hollowheap->root=delete_min(hollowheap->root);
        }
        end=clock();
        time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        printf("To delete/retrieve the minimum %d times the hollow heap took %lf seconds\n",n,time_spent);
        // BINARY HEAP TEST
        int* a=malloc(sizeof(int) *MAX_SIZE);
        for(int i=0;i<n;i++){
            a[i]=testarray[i];
        
        }
        begin=clock();
        build_max_heap(a,n); 
        end=clock();
        time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        printf("To insert %d integers the binary heap took %lf seconds\n",n,time_spent);
        begin=clock();
        //int k=1000000;
        int k=n;
        for(int i=0;i<n;i++){
            extract_max(a,&k);
        }
        end=clock();
        time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        printf("To delete/retrieve the max value %d times the binary heap took %lf seconds\n",n,time_spent);
    }
    printf("I did not include djikstra's test as I figured I could do pretty much everything without it.\n\n");
    printf("Now for time complexity of hollow heap for one operation at various n tests:\n");
    for(int cases=0;cases<=5;++cases){
        int n=size_arr[cases];
        for(int i=0;i<n;i++){
            struct Item* test_item = malloc(sizeof(struct Item));
            test_item->value=i;
            hollowheap->root=insert(test_item,i,hollowheap->root);
        }
        struct Item* test_item2 = malloc(sizeof(struct Item));
        test_item2->value=n+1;
        clock_t begin=clock();
        hollowheap->root=insert(test_item2,n, hollowheap->root);
        clock_t end=clock();
        double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        printf("A single insertion at n=%d took %lf seconds\n",n,time_spent);
        begin=clock();
        hollowheap->root=delete_min(hollowheap->root);
        end=clock();
        time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        printf("A single deletion at n=%d took %lf seconds\n",n,time_spent);
        for(int i=0;i<n;i++){
            hollowheap->root=delete_min(hollowheap->root);
        }
        
    }
    printf("\nnow a test for correctness for hollow heap. if no pairs of numbers print below this is indeed a valid min heap\n");
    for(int i=0;i<100000;i++){
        item_arr[i]->value=i;
        hollowheap->root=insert(item_arr[i],i,hollowheap->root);
    }
    for(int i=0;i<100000;i++){
        if(i!=find_min(hollowheap->root)->value){
            printf("%d %d",i,find_min(hollowheap->root)->value);
        }
        hollowheap->root= delete_min(hollowheap->root);
    }
    
    printf("if nothing printed this is a valid min heap! hurray\n");

    printf("Test for correctness reduce key operation\n");
    item_arr[0]->value=3;
    hollowheap->root= insert(item_arr[0],696969,hollowheap->root);
    if((hollowheap->root= decrease_key(item_arr[0],3,hollowheap->root))->key!=3){
        printf("ICKY\n");
    }
    printf("if ICKY did not print we correctly reduced key\n");

}