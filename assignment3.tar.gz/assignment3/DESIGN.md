Matthew Mullen
Student id number: 1636866

Assignment 3

In this assignment, I created the sliding window interpretation of this assignment using a queue implemented by a linked list and a seperate chaining hashtable. I implemented the queue using a singly linked list. The queue was responsible for holding each key that we put into the hashtable for a given window. The first element of the queue is the "left" side of the sliding window and contains the key that we use to delete the first element in hashtable[key] which is the element to be removed. After which we then count the number of unique pages left in the hashtable at each key using another linkedlist. The hashfunction I used was address % window_size/2, I chose this as it seemed like a good tradeoff between memory and having a large amount of available slots in the hashtable. To save space I made sure to use a hashtable rather than a page sized array to keep counts of pages within a sliding window. I used almost exclusively heap memory so that I was not wasting memory by having a bunch of memory allocated to the stack that I did not use and I made sure to free all dynamically allocated memory upon termination of the program.

Time complexities:
O(n) append for queue
O(1) pop from front of queue
O(1) inserts for hashtable
O(1) deletes for hashtable
O(n^2) counting number of unique pages (this could be reduced to O(n) using a doubly linked list after consulting with TA Matthew G. but I did not have time due to final exams)

