import matplotlib.pyplot as plt
ls=[]
for line in open("out5.dat", 'r'):
    line=line.split()
    countnum=line[1]
    ls.append(countnum)
plt.hist(ls,100)
plt.show()